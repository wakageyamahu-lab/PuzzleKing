# Puzzle King — Android 14 starter

## Build APK from an Android phone (cloud build)
This project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.
1. Sign in or create a GitHub account in Chrome.
2. Create a new **private** repository named `puzzle-king`.
3. Upload the unzipped project files and folders to the repository (keep the `.github/workflows` folder).
4. Open the repository's **Actions** tab and select **Build Puzzle King APK**.
5. Tap **Run workflow** (or wait for the first push build to finish).
6. Open the completed workflow run, scroll to **Artifacts**, and download `PuzzleKing-debug-APK`.
7. Extract the downloaded artifact ZIP and tap `app-debug.apk` to install. Android may ask permission to install unknown apps for your browser; only install APKs you built and trust.

## Current features
- 10x10 block puzzle board
- Three randomly generated pieces per turn
- Row/column clearing, score, and session points
- Reward DANA screen mockup

## Important limitations
- Reward screen is a visual prototype only. It does not send money or submit a real withdrawal.
- Points are demo points and have no cash value.
- No AdMob, login, server, database, fraud checks, or DANA API is connected yet.
- Never put DANA API secrets/private keys in the Android app or public repository.
- A DANA Merchant account alone does not prove that **Disbursement to Balance** API access is enabled. DANA's official docs require merchant registration, selecting the Disbursement to Balance solution, test credentials, sandbox testing/UAT, and production approval.
- Before paying users, create clear earning/withdrawal terms, minimum withdrawal, fraud controls, customer support, privacy policy, and sufficient reward funding. Do not promise cash as a direct reward for watching AdMob rewarded ads.

## Technical stack
Kotlin, Jetpack Compose, Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17, compile/target SDK 35, min SDK 23.
