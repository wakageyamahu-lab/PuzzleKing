package com.puzzleking.game

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

private val Navy = Color(0xFF101A35)
private val Panel = Color(0xFF1B294B)
private val Gold = Color(0xFFFFC857)
private val EmptyCell = Color(0xFF263657)
private val Palette = listOf(Color(0xFF43C6AC), Color(0xFFFF6B6B), Color(0xFF6C8CFF), Color(0xFFFFB347), Color(0xFFC792EA))
private data class Piece(val cells: List<Pair<Int, Int>>, val color: Color)
private val Shapes = listOf(
    listOf(0 to 0), listOf(0 to 0, 0 to 1), listOf(0 to 0, 1 to 0),
    listOf(0 to 0, 0 to 1, 0 to 2), listOf(0 to 0, 1 to 0, 2 to 0),
    listOf(0 to 0, 0 to 1, 1 to 0, 1 to 1),
    listOf(0 to 0, 1 to 0, 2 to 0, 2 to 1),
    listOf(0 to 1, 1 to 0, 1 to 1, 1 to 2),
    listOf(0 to 0, 0 to 1, 0 to 2, 1 to 1),
    listOf(0 to 0, 1 to 0, 1 to 1, 2 to 1)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PuzzleKingApp() }
    }
}

@Composable
private fun PuzzleKingApp() {
    val board = remember { mutableStateListOf<Int>().apply { repeat(100) { add(-1) } } }
    var pieces by remember { mutableStateOf(newPieces()) }
    var selected by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var points by remember { mutableIntStateOf(0) }
    var best by remember { mutableIntStateOf(0) }
    var gameOver by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Pilih balok, lalu ketuk posisi di papan.") }
    var showReward by remember { mutableStateOf(false) }
    var danaNumber by remember { mutableStateOf("") }
    var redeemPoints by remember { mutableStateOf("1000") }

    fun resetGame() {
        repeat(100) { board[it] = -1 }
        pieces = newPieces()
        selected = 0
        score = 0
        points = 0
        gameOver = false
        message = "Game baru dimulai. Semangat!"
    }

    fun fits(piece: Piece, row: Int, col: Int): Boolean =
        piece.cells.all { (dr, dc) ->
            row + dr in 0..9 && col + dc in 0..9 && board[(row + dr) * 10 + col + dc] == -1
        }

    fun place(row: Int, col: Int) {
        if (gameOver || showReward) return
        val piece = pieces.getOrNull(selected) ?: return
        if (!fits(piece, row, col)) {
            message = "Balok tidak muat di sana. Coba posisi lain."
            return
        }
        piece.cells.forEach { (dr, dc) -> board[(row + dr) * 10 + col + dc] = Palette.indexOf(piece.color).coerceAtLeast(0) }
        score += piece.cells.size * 10
        points += piece.cells.size
        val updated = pieces.toMutableList()
        updated[selected] = null
        pieces = updated

        val fullRows = (0..9).filter { r -> (0..9).all { c -> board[r * 10 + c] >= 0 } }
        val fullCols = (0..9).filter { c -> (0..9).all { r -> board[r * 10 + c] >= 0 } }
        fullRows.forEach { r -> (0..9).forEach { c -> board[r * 10 + c] = -1 } }
        fullCols.forEach { c -> (0..9).forEach { r -> board[r * 10 + c] = -1 } }
        val cleared = fullRows.size + fullCols.size
        if (cleared > 0) {
            score += cleared * 100
            points += cleared * 5
            message = "Mantap! $cleared baris/kolom dibersihkan."
        } else message = "Bagus! Balok berhasil dipasang."

        best = maxOf(best, score)
        if (pieces.all { it == null }) {
            pieces = newPieces()
            selected = 0
        } else {
            selected = pieces.indexOfFirst { it != null }.coerceAtLeast(0)
        }
        val hasMove = pieces.filterNotNull().any { p ->
            (0..9).any { r -> (0..9).any { c -> fits(p, r, c) } }
        }
        if (!hasMove) {
            gameOver = true
            message = "Game over! Tekan Main Lagi untuk mencoba kembali."
        }
    }

    MaterialTheme {
        if (showReward) {
            RewardScreen(
                points = points,
                danaNumber = danaNumber,
                onDanaChange = { danaNumber = it },
                redeemPoints = redeemPoints,
                onRedeemChange = { redeemPoints = it },
                onBack = { showReward = false }
            )
        } else {
            Column(
                Modifier.fillMaxSize().background(Navy).padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("♛ PUZZLE KING", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Black)
                        Text("BLOCK PUZZLE • PLAY & COLLECT", color = Color.LightGray, fontSize = 10.sp)
                    }
                    Text("👑", fontSize = 32.sp)
                }
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    StatCard("SKOR", score.toString(), Modifier.weight(1f))
                    StatCard("REKOR", best.toString(), Modifier.weight(1f))
                    StatCard("POIN DEMO", points.toString(), Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
                Text(message, color = Color.White, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                Column(
                    Modifier.fillMaxWidth().aspectRatio(1f).background(Panel, RoundedCornerShape(12.dp)).padding(5.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    repeat(10) { r ->
                        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                            repeat(10) { c ->
                                val idx = r * 10 + c
                                Box(
                                    Modifier.weight(1f).fillMaxHeight()
                                        .background(if (board[idx] >= 0) Palette[board[idx]] else EmptyCell, RoundedCornerShape(3.dp))
                                        .border(0.5.dp, Color(0xFF405174), RoundedCornerShape(3.dp))
                                        .clickable { place(r, c) }
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("PILIH BALOK", color = Gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Row(Modifier.fillMaxWidth().height(100.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    pieces.forEachIndexed { index, piece ->
                        Box(
                            Modifier.weight(1f).fillMaxHeight()
                                .background(if (selected == index) Color(0xFF34466D) else Panel, RoundedCornerShape(10.dp))
                                .border(if (selected == index) 2.dp else 1.dp, if (selected == index) Gold else Color(0xFF405174), RoundedCornerShape(10.dp))
                                .clickable(enabled = piece != null) { selected = index },
                            contentAlignment = Alignment.Center
                        ) {
                            if (piece == null) Text("✓", color = Gold, fontSize = 24.sp)
                            else PiecePreview(piece)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { resetGame() }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Navy)) {
                        Text("MAIN LAGI", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(onClick = { showReward = true }, modifier = Modifier.weight(1f)) {
                        Text("REWARD DANA", color = Color.White)
                    }
                }
                Spacer(Modifier.height(7.dp))
                Text("Poin demo belum bernilai uang dan belum dapat dicairkan.", color = Color.LightGray, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun RewardScreen(
    points: Int,
    danaNumber: String,
    onDanaChange: (String) -> Unit,
    redeemPoints: String,
    onRedeemChange: (String) -> Unit,
    onBack: () -> Unit
) {
    var info by remember { mutableStateOf("Penukaran belum aktif. Ini hanya tampilan demo.") }
    Column(
        Modifier.fillMaxSize().background(Navy).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("‹ KEMBALI", color = Gold, modifier = Modifier.clickable { onBack() })
            Spacer(Modifier.weight(1f))
            Text("REWARD DANA", color = Gold, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(30.dp))
        Text("POIN TERSEDIA", color = Color.LightGray, fontSize = 12.sp)
        Text(points.toString(), color = Gold, fontSize = 38.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(22.dp))
        OutlinedTextField(
            value = danaNumber,
            onValueChange = onDanaChange,
            label = { Text("Nomor HP akun DANA (demo)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = redeemPoints,
            onValueChange = onRedeemChange,
            label = { Text("Jumlah poin yang ingin ditukar") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(16.dp))
        Button(onClick = { info = "Pengajuan belum dikirim. Integrasi server dan persetujuan DANA masih diperlukan." }, modifier = Modifier.fillMaxWidth()) {
            Text("AJUKAN PENUKARAN")
        }
        Spacer(Modifier.height(14.dp))
        Text(info, color = Gold, fontSize = 12.sp)
        Spacer(Modifier.weight(1f))
        Text("Jangan masukkan nomor DANA asli pada versi demo. Belum ada transaksi sungguhan.", color = Color.LightGray, fontSize = 11.sp)
    }
}

private fun newPieces(): List<Piece?> = List(3) {
    Piece(Shapes[Random.nextInt(Shapes.size)], Palette[Random.nextInt(Palette.size)])
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(10.dp)).padding(9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Color.LightGray, fontSize = 9.sp)
        Text(value, color = Gold, fontSize = 19.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun PiecePreview(piece: Piece) {
    val maxR = piece.cells.maxOf { it.first } + 1
    val maxC = piece.cells.maxOf { it.second } + 1
    Column(verticalArrangement = Arrangement.spacedBy(3.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        repeat(maxR) { r ->
            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                repeat(maxC) { c ->
                    Box(Modifier.size(13.dp).background(if ((r to c) in piece.cells) piece.color else Color.Transparent, RoundedCornerShape(2.dp)))
                }
            }
        }
    }
}
